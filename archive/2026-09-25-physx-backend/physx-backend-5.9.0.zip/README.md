# Backend NVIDIA PhysX 5.9 — legado de estudo

Este ZIP preserva o backend de física PhysX do MatterEngine como ele estava em
**25 de setembro de 2026**, no último commit em que a suíte passava
inteiramente sobre ele (`ctest` 3/3). Não foi apagado porque a calibragem do
ragdoll ativo sobre coordenadas reduzidas é material de estudo, e porque uma
migração de motor físico precisa de caminho de volta.

## Por que saiu

A etapa seguinte do projeto é substituir a pelve cinemática por uma raiz
dirigida por força (PD forte). Essa calibragem se apoiava em três coisas que
são PhysX puro:

- `computeGravityCompensation` usado como feedforward por tick;
- a semântica dos drives de articulação (`PxArticulationDrive`);
- escrita direta no `PxArticulationCache`.

Calibrar antes de trocar de motor significaria calibrar duas vezes. A troca
foi feita primeiro, com a suíte de testes verde e recém-escrita servindo de
critério de aceitação — ela passa pela interface neutra, não pelo PhysX.

## Conteúdo

| Caminho | O que é |
|---|---|
| `src/Engine/Physics/PhysX/` | o backend completo: 3.532 + 503 + 87 linhas + header interno |
| `src/Engine/Physics/*.hpp` | **a interface neutra como era neste momento** — o contrato que este backend implementava |
| `cmake/physx-fetchcontent.cmake` | bloco `FetchContent` com o commit fixado |
| `cmake/physx-warning-suppressions.cmake` | supressões de aviso por target de terceiro (MSVC C5054/C5055, GCC 16 `-Wvolatile`) |
| `cmake/matterphysics-target.cmake` | o target `MatterPhysics` como era, linkando `physx_lib` |

Os headers neutros estão inclusos de propósito: a migração para Jolt
**estreitou** o contrato (`RagdollDynamics3D` perdeu dez campos sem
consumidor, `PhysicsSceneSettings3D` ganhou limites de pré-alocação). Sem a
cópia do contrato antigo, este backend não compilaria contra a árvore atual, e
seria impossível dizer se a diferença é bug ou evolução deliberada.

## Versão fixada do SDK

```
https://github.com/NVIDIA-Omniverse/PhysX.git
commit 517a0073715120e114ee055b63b26c95e00d9039
tag oficial 110.1-omni-and-physx-5.9.0
```

Configuração: CPU estático, GPU rigid bodies desligados, sem snippets nem PVD.

## Como restaurar para estudo

1. Extrair o ZIP num diretório fora da árvore ativa (não sobrescrever `src/`).
2. Para compilar de fato: recolocar os três blocos de `cmake/` no
   `CMakeLists.txt`, restaurar `src/Engine/Physics/PhysX/` e usar os headers
   neutros **desta cópia**, não os atuais.
3. As fronteiras de arquitetura (`tools/check-architecture.sh`) rejeitam
   `physx::` fora de `Engine/Physics/PhysX` — isso continua valendo, e foi
   justamente o que tornou a troca viável. Ao restaurar, a busca volta a ter
   resultado legítimo dentro dessa pasta.

## O que este backend fazia e o Jolt não faz igual

Registrado para quem comparar os dois:

- **Coordenadas reduzidas.** A articulação PhysX é um sistema em coordenadas
  reduzidas com cache de estado (`PxArticulationCache`). O ragdoll do Jolt é
  corpos + constraints com motores. Não há equivalente de matriz de massa,
  Jacobiano denso ou matriz de momento centroidal prontos.
- **`computeGravityCompensation`.** Não existe no Jolt. Foi reimplementado no
  lado neutro, em `Engine/Physics/Articulation/ArticulationGravity3D`, como
  torque de gravidade recursivo sobre a árvore do perfil.
- **Cache de colisor.** Nada, na verdade. O formato `.mecollider` guarda os
  PONTOS dos hulls produzidos pelo V-HACD, não binário cozido do PhysX — e o
  layout de `physx::PxVec3` é idêntico a três floats. O backend Jolt lê os
  mesmos arquivos sem conversão e sem invalidar o cache existente. A suspeita
  inicial de que o cache seria incompatível estava errada; foi desfeita ao ler
  `readCollisionCache` em `PhysXCooking3D.cpp`.
