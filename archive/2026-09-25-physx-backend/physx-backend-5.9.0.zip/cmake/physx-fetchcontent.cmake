# PhysX e um detalhe privado do modulo de fisica. Fixamos o commit da versao
# oficial 5.9.0 para que uma atualizacao remota nunca altere a simulacao de uma
# build existente. O backend CPU estatico e a configuracao portavel para o
# editor; GPU rigid bodies poderao ser habilitados futuramente como outro
# perfil, depois de medirmos uma cena que realmente amortize o custo do CUDA.
set(PHYSX_PRESET "" CACHE STRING "" FORCE)
set(PX_GENERATE_GPU_PROJECTS OFF CACHE BOOL "" FORCE)
set(PX_GENERATE_STATIC_LIBRARIES ON CACHE BOOL "" FORCE)
set(PX_GENERATE_GPU_STATIC_LIBRARIES OFF CACHE BOOL "" FORCE)
set(PX_BUILDSNIPPETS OFF CACHE BOOL "" FORCE)
set(PX_BUILDPVDRUNTIME OFF CACHE BOOL "" FORCE)
set(NV_USE_STATIC_WINCRT OFF CACHE BOOL "" FORCE)
FetchContent_Declare(
    PhysX
    GIT_REPOSITORY https://github.com/NVIDIA-Omniverse/PhysX.git
    # Tag oficial: 110.1-omni-and-physx-5.9.0
    GIT_TAG 517a0073715120e114ee055b63b26c95e00d9039
    SOURCE_SUBDIR physx
)
