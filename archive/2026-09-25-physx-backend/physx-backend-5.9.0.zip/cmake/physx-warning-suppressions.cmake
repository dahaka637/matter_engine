if(MSVC)
    # MSVC 14.43 passou a emitir C5054/C5055 para operacoes entre enums que o
    # codigo oficial 5.9.0 ainda usa e o PhysX compila seus fontes com /WX.
    # Suprimimos apenas esses dois diagnosticos nos targets de terceiros; os
    # avisos da MatterEngine continuam integralmente ativos.
    foreach(physx_target
            PhysXFoundation PhysXCommon PhysX PhysXExtensions PhysXCooking
            PhysXCharacterKinematic PhysXPvdSDK PhysXTask PhysXVehicle
            LowLevel LowLevelAABB LowLevelDynamics SceneQuery
            SimulationController)
        if(TARGET ${physx_target})
            target_compile_options(${physx_target} PRIVATE /wd5054 /wd5055)
        endif()
    endforeach()
elseif(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
    # O PhysX 5.9 ainda incrementa um contador volatile no backend Unix. GCC
    # 16 diagnostica isso como -Wvolatile e o SDK promove todos os avisos a
    # erro. A supressao fica restrita aos targets de terceiros.
    foreach(physx_target
            PhysXFoundation PhysXCommon PhysX PhysXExtensions PhysXCooking
            PhysXCharacterKinematic PhysXPvdSDK PhysXTask PhysXVehicle
            LowLevel LowLevelAABB LowLevelDynamics SceneQuery
            SimulationController)
        if(TARGET ${physx_target})
            target_compile_options(${physx_target} PRIVATE
                -Wno-error
                -Wno-volatile)
        endif()
    endforeach()
endif()
