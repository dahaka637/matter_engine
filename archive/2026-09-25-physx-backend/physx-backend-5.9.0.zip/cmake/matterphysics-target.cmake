# API publica neutra + backend PhysX privado. Nenhum consumidor recebe os
# includes ou tipos nativos do SDK; trocar/configurar o backend nao contamina a
# camada Workbench nem o restante da engine.
add_library(MatterPhysics STATIC
    src/Engine/Physics/PhysicalBodyBuilder3D.cpp
    src/Engine/Physics/RagdollProfile3D.cpp
    src/Engine/Physics/WindShelter3D.cpp
    src/Engine/Physics/PhysX/PhysXEngine3D.cpp
    src/Engine/Physics/PhysX/PhysXCooking3D.cpp
    src/Engine/Physics/PhysX/PhysXScene3D.cpp
)
target_include_directories(MatterPhysics PUBLIC src)
target_link_libraries(MatterPhysics
    PUBLIC MatterCore
    PRIVATE physx_lib vhacd nlohmann_json::nlohmann_json
)
target_compile_definitions(MatterPhysics PRIVATE PX_PHYSX_STATIC_LIB)
if(MSVC)
    # Dependencias de terceiros sao compiladas com seus proprios perfis. Estas
    # opcoes mantem diagnosticos fortes no adaptador escrito pela MatterEngine.
    target_compile_options(MatterPhysics PRIVATE /W4 /permissive- /utf-8)
else()
    target_compile_options(MatterPhysics PRIVATE -Wall -Wextra -Wpedantic)
endif()

